
# Moe Framework

MOE es un framework MVC desarrollado para facilitar el desarrollo de forma organizada, rápida y segura. Su punto fuerte es la facilidad de separar la lógica empleada por el desarrollador de las plantillas html.

# youthcms
CMS para el proyecto youth

