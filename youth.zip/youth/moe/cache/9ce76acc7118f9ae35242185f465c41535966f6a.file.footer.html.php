<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-02-18 15:07:27
         compiled from "..\views\footer.html" */ ?>
<?php /*%%SmartyHeaderCode:3004556c38463e70f21-32463188%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9ce76acc7118f9ae35242185f465c41535966f6a' => 
    array (
      0 => '..\\views\\footer.html',
      1 => 1455826040,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '3004556c38463e70f21-32463188',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56c38463e74da1_69882651',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56c38463e74da1_69882651')) {function content_56c38463e74da1_69882651($_smarty_tpl) {?><div class="footer-main">
                    Copyright &copy La taberna, 2016
                </div>
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->


        
    </body>
</html><?php }} ?>
