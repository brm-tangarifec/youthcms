<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-03-02 11:55:15
         compiled from "..\views\taberna\header.html" */ ?>
<?php /*%%SmartyHeaderCode:1011656cb21637cda21-59711854%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '31a4923ac4f39d1ab4c5002d363cf72ccb9bd4cd' => 
    array (
      0 => '..\\views\\taberna\\header.html',
      1 => 1456937713,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1011656cb21637cda21-59711854',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56cb21637dd431_92827087',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56cb21637dd431_92827087')) {function content_56cb21637dd431_92827087($_smarty_tpl) {?><!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>La Taberna de Moe</title>
        
        <!-- bootstrap 3.0.2 -->
        <link href="/youth/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="/youth/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Ionicons -->
        <link href="/youth/css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- google font -->
        <link href='http://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
        <!-- Theme style -->
        <link href="/youth/css/style.css" rel="stylesheet" type="text/css" />
        <link href="/youth/css/style-admin.css" rel="stylesheet" type="text/css" />
        <!--Estilos editor-->
        <link type="text/css" rel="stylesheet" href="/youth/css/raptor/raptor-front-end.min.css" />
        <link type="text/css" rel="stylesheet" href="/youth/css/raptor/raptor.mammoth.min.css" />

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <?php echo '<script'; ?>
 src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"><?php echo '</script'; ?>
>
          <?php echo '<script'; ?>
 src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"><?php echo '</script'; ?>
>
        <![endif]--><!-- jQuery 2.0.2 -->
        <?php echo '<script'; ?>
 src="/youth/js/libs.youth.min.js" type="text/javascript"><?php echo '</script'; ?>
>
        

        <!-- Bootstrap ->
        <?php echo '<script'; ?>
 src="/youth/js/bootstrap.min.js" type="text/javascript"><?php echo '</script'; ?>
>
        
        <!-- Taberna -->
        <?php echo '<script'; ?>
 src="/youth/js/taberna/taberna.js" type="text/javascript"><?php echo '</script'; ?>
>
    </head>
    <body class="skin-black">
        <!-- header logo: style can be found in header.less -->
        <header class="header container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <a href="./" class="logo">
                        <!-- Add the class icon to your logo image or logo icon to add the margining -->
                       La taberna
                    </a>
                </div>
            </div>
    
        </header><?php }} ?>
