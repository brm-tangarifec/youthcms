<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-02-25 09:08:28
         compiled from "..\views\taberna\footer.html" */ ?>
<?php /*%%SmartyHeaderCode:1521356cb21637ece37-95014960%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'eeea510df6a31dde9e9f1fbbd5d58302f8228200' => 
    array (
      0 => '..\\views\\taberna\\footer.html',
      1 => 1456374732,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1521356cb21637ece37-95014960',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56cb21637ece31_78464264',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56cb21637ece31_78464264')) {function content_56cb21637ece31_78464264($_smarty_tpl) {?><footer class="container-fluid">
                   <div class="row">
                   	<div class="col-lg-12">
                   		<p class="text-center">Copyright &copy; La taberna, 2016</p>
                   	</div>
                   </div>
      
            
        </footer><!-- ./wrapper -->


        
    </body>
</html><?php }} ?>
