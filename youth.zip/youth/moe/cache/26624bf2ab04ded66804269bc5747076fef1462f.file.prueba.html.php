<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-02-05 16:00:32
         compiled from "../views2/prueba.html" */ ?>
<?php /*%%SmartyHeaderCode:212748798456b50d70cc9a13-88597724%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '26624bf2ab04ded66804269bc5747076fef1462f' => 
    array (
      0 => '../views2/prueba.html',
      1 => 1454705931,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '212748798456b50d70cc9a13-88597724',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_56b50d70cebb90_95774596',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_56b50d70cebb90_95774596')) {function content_56b50d70cebb90_95774596($_smarty_tpl) {?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
</head>
<body>
	Prueba
</body>
</html><?php }} ?>
